﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumCSharp
{


    //Strongly typed properties - Enum
    enum PropertyType
    {
        Id,
        Name,
        LinkText,
        CssName,
        ClassName
    }



    class CustomCollections
    {
        //Declaring as a property to use across all classes 
        public static IWebDriver driver { get; set; }





    }
}
