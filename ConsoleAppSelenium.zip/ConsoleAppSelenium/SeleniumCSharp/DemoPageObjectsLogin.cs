﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumCSharp
{
    class DemoPageObjectsLogin: CustomCollections
    {

        // Page Object Model
        // Declaring Objects
         IWebElement txtUsername => driver.FindElement(By.Name("UserName"));

         IWebElement txtPassword => driver.FindElement(By.Name("Password"));

         IWebElement btnLogin => driver.FindElement(By.Name("Login"));




        //Object Methods
        // Instead of returnType void -> we can use the next page object class name (DemoPageObjectsLanding) to address 'Page Navigation' Concept
        public DemoPageObjectsLanding Login(string userName, string password) 
        {
            //UserName
            txtUsername.SendKeys(userName);

            //Password
            txtPassword.SendKeys(password);

            //Click Login Button
            btnLogin.Submit();

            //Return the next page objects (from DemoPageObjectsLanding) to address 'Page Navigation' Concept
            return new DemoPageObjectsLanding();
        }



    }
}
