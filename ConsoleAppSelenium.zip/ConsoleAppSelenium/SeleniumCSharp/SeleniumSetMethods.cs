﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium.Support.UI;

namespace SeleniumCSharp
{
    // added 'public static' with the class name to for 'this' to use C# Extension methods
    public static class SeleniumSetMethods
    {

        //Way - 4
        // Extended method for entering text in the control using C# Extension methods
        //EnterText
        public static void EnterText(this IWebElement element, string value)
        {
            element.SendKeys(value);
        }

        //Click on a button, checkbox, option etc.
        public static void Click(this IWebElement element)
        {
            element.Submit();
        }

        //Select a drop-down
        public static void SelectDropDown(this IWebElement element, string value)
        {
            new SelectElement(element).SelectByText(value);
        }









        /*
            //Way - 3
            //EnterText
            public static void EnterText(IWebElement element, string value)
            {
                element.SendKeys(value);
            }

            //Click on a button, checkbox, option etc.
            public static void Click(IWebElement element)
            {
                element.Submit();
            }

            //Select a drop-down
            public static void SelectDropDown(IWebElement element, string value)
            {
                new SelectElement(element).SelectByText(value);
            }
        */










        /* Way - 2
         * EnterText
         public static void EnterText(string element, string value, PropertyType elementType)
         {
             if (elementType == PropertyType.Id)
                 CustomCollections.driver.FindElement(By.Id(element)).SendKeys(value);
             if (elementType == PropertyType.Name)
                 CustomCollections.driver.FindElement(By.Name(element)).SendKeys(value);
         }

         //Click on a button, checkbox, option etc.
         public static void Click(string element, PropertyType elementType)
         {
             if (elementType == PropertyType.Id)
                 CustomCollections.driver.FindElement(By.Id(element)).Click();
             if (elementType == PropertyType.Name)
                 CustomCollections.driver.FindElement(By.Name(element)).Click();
         }


         //Select a drop-down
         public static void SelectDropDown(string element, string value, PropertyType elementType)
         {

             if (elementType == PropertyType.Id)
                 new SelectElement(CustomCollections.driver.FindElement(By.Id(element))).SelectByText(value);
             if (elementType == PropertyType.Name)
                 new SelectElement(CustomCollections.driver.FindElement(By.Name(element))).SelectByText(value);
         }
        */






        /* Way - 1
        //EnterText
        public static void EnterText(IWebDriver driver, string element, string value, string elementType)
        {
            if(elementType == "Id")
                driver.FindElement(By.Id(element)).SendKeys(value);
            if(elementType == "Name")
                driver.FindElement(By.Name(element)).SendKeys(value);
        }

        //Click on a button, checkbox, option etc.
        public static void Click(IWebDriver driver, string element, string elementType)
        {
            if (elementType == "Id")
                driver.FindElement(By.Id(element)).Click();
            if (elementType == "Name")
                driver.FindElement(By.Name(element)).Click();
        }


        //Select a drop-down
        public static void SelectDropDown(IWebDriver driver, string element, string value, string elementType)
        {
            //Way - 1
            //SelectElement selectElement = new SelectElement();

            //Way - 2
            if (elementType == "Id")
                new SelectElement(driver.FindElement(By.Id(element))).SelectByText(value);
            if (elementType == "Name")
                new SelectElement(driver.FindElement(By.Name(element))).SelectByText(value);
        }
        */



    }
}
