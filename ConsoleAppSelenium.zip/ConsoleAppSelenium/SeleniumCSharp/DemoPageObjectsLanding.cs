﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;


namespace SeleniumCSharp
{
    class DemoPageObjectsLanding: CustomCollections
    {

        /* Way - 1 > To Initialize the objects - we'd need pageFactory.init elements
        * Initiating the contructor
        * Outdated
        public DemoPageObjects()
        {
            PageFactory.InitElements(CustomCollections.driver, this);
        }*/

         /* Way -2 > To Initialize the objects - we'd need pageFactory.init elements
          * Initiating the contructor
          * Not Required!
          private RemoteWebDriver _driver;
          public DemoPageObjects(RemoteWebDriver driver) => _driver = driver;
        */




        // Way -2 > Page Object Model
        // Declaring Objects
         IWebElement DropDownTitleID => driver.FindElement(By.Id("TitleId"));

         IWebElement InputFieldTxtInitial => driver.FindElement(By.Name("Initial"));

         IWebElement InputFieldTxtFirstName => driver.FindElement(By.Name("FirstName"));

         IWebElement InputFieldTxtMiddleName => driver.FindElement(By.Name("MiddleName"));

         IWebElement btnSave => driver.FindElement(By.Name("Save"));




        //Object Methods
        public void FillLandingForm(string initial, string FirstName, string middleName)
        {

            //Way - 1 > POM
            //Initial
            InputFieldTxtInitial.SendKeys(initial);
            
            //FirstName
            InputFieldTxtFirstName.SendKeys(FirstName);

            //MiddleName
            InputFieldTxtMiddleName.SendKeys(middleName);

            //Click Save Button
            btnSave.Submit();
            



            /*
            //Way - 2 > Custom Methods 
            //Initial
            InputFieldTxtInitial.EnterText(initial);

            //FirstName
            InputFieldTxtFirstName.EnterText(FirstName);

            //MiddleName
            InputFieldTxtMiddleName.EnterText(middleName);

            //Click Save Button
            btnSave.Submit();
            */              



            /*Way - 1 > Custom Methods 
            //Initial
            SeleniumSetMethods.EnterText(InputFieldTxtInitial, initial);

            //FirstName
            SeleniumSetMethods.EnterText(InputFieldTxtFirstName, FirstName);

            //MiddleName
            SeleniumSetMethods.EnterText(InputFieldTxtMiddleName, middleName);

            //Click Save Button
            SeleniumSetMethods.Click(btnSave);
            */


        }











        /*Way - 1 > Page Object Model
         * Declaring Objects with property
         * Outdated 
         [FindsBy(How = How.Id, Using = "TitleId")]
         public IWebElement DropDownTitleID { get; set; }

        [FindsBy(How = How.Name, Using = "Initial")]
        public IWebElement InputFieldTxtInitial { get; set; }

        [FindsBy(How = How.Name, Using = "Save")]
        public IWebElement btnSave { get; set; }
        */





    }
}
