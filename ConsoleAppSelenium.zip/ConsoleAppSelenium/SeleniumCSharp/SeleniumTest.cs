﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;
using System.Threading.Tasks;
using SeleniumExtras.PageObjects;
using System.Threading;

namespace SeleniumCSharp
{
    class SeleniumTest
    {

        /* Global variable
         * creating the reference for browser
        IWebDriver driver = new ChromeDriver();
        */

        


        static void Main(string[] args)
        {
            //Console.WriteLine("test");
        }


        
        [SetUp]
        public void Initialize()
        {

            //creating the reference for browser with the Custom Class
            CustomCollections.driver = new ChromeDriver();

            //Maximize browser window
            CustomCollections.driver.Manage().Window.Maximize();

            //Navigate to a demo site page
            CustomCollections.driver.Navigate().GoToUrl("https://demosite.executeautomation.com/Login.html");

            Console.WriteLine("Navigated to the specified URL");
        }


        [Test]
        public void ExecuteTest()
        {

            /*          
             // to get the data from Excel
             //Initialize the excelLib
             ExcelLib.PopulateInCollection(@"E:\Resources (Hafij)\Resources (Office)\Projects\SelfLearning\SpecFlow-Selenium-C#\C# Selenium\ConsoleAppSelenium\SeleniumCSharp\Utils\Data.xlsx");
           */ 


            //Way -1 > Initialize the page object by calling its reference for 'DemoPageObjectsLanding'
            //DemoPageObjectsLanding pageLanding = new DemoPageObjectsLanding();


            //Initialize the page object by calling its reference for 'DemoPageObjectsLogin'
            DemoPageObjectsLogin pageLogin = new DemoPageObjectsLogin();


            //Way 2 > Initialize the page object by calling its reference for 'DemoPageObjectsLanding'
            DemoPageObjectsLanding pageLanding = pageLogin.Login("TestUser1", "tPass12");


            // Example - 4 / Page Object Model
            //Invoking Page Objects
            pageLanding.FillLandingForm("Test", "Hafijur", "Rahman");


           /*
            // to get the data from excel
             DemoPageObjectsLanding pageLanding = pageLogin.Login(ExcelLib.ReadData(1, "UserName"), ExcelLib.ReadData(1, "Password"));
             pageLanding.FillLandingForm(ExcelLib.ReadData(1, "Initial"), ExcelLib.ReadData(1, "FirstName"), ExcelLib.ReadData(1, "MiddleName"));
           */      





            Console.WriteLine("Executed the instructions");


            Thread.Sleep(2000);


            /*Example - 3 / Page Object Model
             *Invoking Page Objects
            //Initial
            pageLanding.InputFieldTxtInitial.SendKeys("Test");

            //Click
            pageLanding.btnSave.Click();
            */



            /* Example - 2 / CustomMethods
            //Title
            SeleniumSetMethods.SelectDropDown("TitleId", "Mr.", PropertyType.Id);
                     
            //Initial
            SeleniumSetMethods.EnterText("Initial", "Test", PropertyType.Name);
            //Get the value
            Console.WriteLine("The value of Title is: " + SeleniumGetMethods.GetTextDropDown("TitleId", PropertyType.Id));
            Console.WriteLine("The value of Initial is: " + SeleniumGetMethods.GetTextInputField("Initial", PropertyType.Name));

            //Click
            SeleniumSetMethods.Click("Save", PropertyType.Name);
            */
        }



        [TearDown]
        public void CleanUp()
        {
            //Close the browser
            CustomCollections.driver.Close();
            Console.WriteLine("Browser is closed!");
        }





              /* Example - 1 / CustomMethods
                [SetUp]
                public void Initialize()
                {
                    //Navigate to Google page
                    driver.Navigate().GoToUrl("https://www.google.com/");

                    Console.WriteLine("Navigated to the specified URL");
                }

                [Test]
                public void ExecuteTest()
                {
                    //Find the element
                    IWebElement element = driver.FindElement(By.Name("q"));

                    //Perform send keys
                    element.SendKeys("Automation step by step");

                    Console.WriteLine("Executed the instructions");
                }

                [TearDown]
                public void CleanUp()
                {
                    //Close the browser
                    driver.Close();
                    Console.WriteLine("Browser is closed!");
                }
             */






    }




}
