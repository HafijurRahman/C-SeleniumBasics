﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium.Support.UI;
using System.Linq;

namespace SeleniumCSharp
{
    class SeleniumGetMethods
    {


        //Way-2 >
        //Get text out from an input fields
        public static string GetTextInputField(IWebElement element)
        {
           return element.GetAttribute("value");
        }

        //Get text out from a drop-down 
        public static string GetTextDropDown(IWebElement element)
        {

            return new SelectElement(element).AllSelectedOptions.SingleOrDefault().Text;
        }









         /* Way-1 >
             * Get text out from an input fields
            public static string GetTextInputField(string element, PropertyType elementType)
            {
                if (elementType == PropertyType.Id)
                   return CustomCollections.driver.FindElement(By.Id(element)).GetAttribute("value");
                if (elementType == PropertyType.Name)
                    return CustomCollections.driver.FindElement(By.Name(element)).GetAttribute("value");
                else
                    return String.Empty;
            }


            //Get text out from a drop-down 
            public static string GetTextDropDown(string element, PropertyType elementType)
            {
                if (elementType == PropertyType.Id)
                    return new SelectElement(CustomCollections.driver.FindElement(By.Id(element))).AllSelectedOptions.SingleOrDefault().Text;
                if (elementType == PropertyType.Name)
                    return new SelectElement(CustomCollections.driver.FindElement(By.Name(element))).AllSelectedOptions.SingleOrDefault().Text;
                else
                    return String.Empty;
            }
         */





    }
}
